POSITIVE={"good","clean","fast","helpful","improved"}
NEGATIVE={"bad","dirty","slow","rude","smoke","broken"}
NEGATORS={"not","never","no"}
def score(text):
    words=text.lower().replace("."," ").replace(","," ").split()
    total=0
    for i,word in enumerate(words):
        value=1 if word in POSITIVE else -1 if word in NEGATIVE else 0
        if i>0 and words[i-1] in NEGATORS:
            value=-value
        total+=value
    return total
def label(text):
    value=score(text)
    return "positive" if value>0 else "negative" if value<0 else "neutral"
for c in ["Roads are clean and the bus was fast.",
          "Smoke from the factory, air is bad.",
          "The staff were not helpful.",
          "Not bad, service improved."]:
    print(f"{label(c):8} | {c}")
